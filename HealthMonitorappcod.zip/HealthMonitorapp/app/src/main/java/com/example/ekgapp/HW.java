package com.example.ekgapp;

public class HW {
    protected
    String readEcg(){
        return "11,17,7,19,15,10,14,8";
    }
    String readPres(){return"12,9,11,5";}


};
